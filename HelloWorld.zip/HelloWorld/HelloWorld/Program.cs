﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    interface iHello
    {
        void HelloMethod();
    }


    public class Program : iHello
    {
        #region iHello Member
        public void HelloMethod()
        {
            Console.WriteLine("Hello World");
            Console.ReadKey();
        }
        #endregion

        public static void Main()
        {
            Program p = new Program();
            p.HelloMethod();
        }

    }



   
}
