﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication1
{
    public class Datahelper
    {
        public static string GetMsg(string strMsg)
        {
          

            string Msg = "";
            //Create Connection
            //SqlConnection con = new SqlConnection(@"Data Source=PC\SQLEXPRESS;Initial Catalog=Sample;Integrated Security=True");
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            //SQL Command
            SqlCommand cmd = new SqlCommand("select * from GetMessage", con);
            con.Open();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())

            {

                Msg = rd["Message"].ToString();

            }
            //close Connections
            //rd.Close();
            con.Close();

            return Msg;

        }
    
        
}
}