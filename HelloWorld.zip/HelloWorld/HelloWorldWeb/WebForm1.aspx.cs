﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace HelloWorldWeb
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //WebService1SoapClient web
            ServiceReference1.WebService1SoapClient Wb = new ServiceReference1.WebService1SoapClient();
            string strMsg = Wb.HelloWorld();
            Lbltext.Text = strMsg.ToString();
            StringBuilder errorMessages = new StringBuilder();

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
                //SqlConnection con = new SqlConnection(@"Data Source=PC\SQLEXPRESS;Initial Catalog=Sample;Integrated Security=True");
                con.Open();
                //SQL Command
                SqlCommand cmd = new SqlCommand("Insert into WriteMsg values(@strMsgs)", con);

                cmd.Parameters.AddWithValue("@strMsgs", strMsg);
                cmd.ExecuteNonQuery();
                
                con.Close();
                Lbltext.Text = "<b>" + Lbltext.Text + "</b>";
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    errorMessages.Append("Index #" + i + "\n" +
                        "Message: " + ex.Errors[i].Message + "\n" +
                        "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                        "Source: " + ex.Errors[i].Source + "\n" +
                        "Procedure: " + ex.Errors[i].Procedure + "\n");
                }
                Console.WriteLine(errorMessages.ToString());
            }
        }



    }
    
}