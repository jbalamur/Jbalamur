﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace WebAppMVC.Models
{
    public class DBContext
    {
        //Connection variable
        SqlConnection conn = new SqlConnection();

        //List<GetMessage> Msg = new List<GetMessage>();
        //public string Message { get; set; }
        string strMessage;
        GetMessage DB = null;

     
        public string ReadMessage()
        

        {
           
                conn.ConnectionString = "Data Source = PC\\SQLEXPRESS;Initial Catalog = Sample; Integrated Security = True";

               
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from GetMessage", conn);

                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())

                {

                    DB = new GetMessage();
                   

                    strMessage = rd["Message"].ToString();
                  
                    
                

               }
            return strMessage;
      


     }






        

    }
        
           

        }



    

   
