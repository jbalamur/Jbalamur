﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAppMVC.Models;


namespace WebAppMVC.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
       public DBContext DB  = new DBContext();



        public ActionResult Index()
        {
            DBContext DB = new DBContext();
            //DB.ReadMessage();
            ViewData["Msgs"] = DB.ReadMessage();

            return View();
        }
       


    }
}