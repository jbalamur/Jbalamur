﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InherHelloWorld
{
    public class baseclass
    {
        

        public void PrintMsg()
        {
           Console.WriteLine("base class");
        }
    }


    public class DerivedClass : baseclass
    {
        #region iHello Member
        public void HelloMethod()
        {
            Console.WriteLine("Hello World");
            Console.ReadKey();
        }
        #endregion



    }
    public class Inheritance
    {
        public static void Main(string[] args)
        {
            baseclass b = new baseclass();
            DerivedClass d = new DerivedClass();
            b.PrintMsg();
            d.PrintMsg();
            d.HelloMethod(); 
            

        }
    }
}
