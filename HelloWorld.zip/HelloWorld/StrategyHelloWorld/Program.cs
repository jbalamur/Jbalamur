﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace StrategyHelloWorld
{
    class Program
    {

        StratSort MySort = new StratSort(new QuickSort);
        MySort.Sort(data);

        MySort = new StrategySort(new BubbleSort());
        MySort.Sort(data);

      class QuickSort()
        {
           ...
        }

        class BubbleSort()
        {
           ...
        }
        static void Main(string[] args)
        {
        }
    }
}
