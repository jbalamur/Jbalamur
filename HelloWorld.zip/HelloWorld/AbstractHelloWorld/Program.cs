﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractHelloWorld
{
    public abstract class Message
    {
        public void Msg()
        {
       }

    } 
    public class Program : Message
    {
       // public override void Msg()
        //{
        //    Console.WriteLine("Hello World");
       //     Console.ReadKey();
       // }


        public static void Main()
        {
            Message M = new Program();
            M.Msg();

        }
    }
}
